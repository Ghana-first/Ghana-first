GHANA FIRST FORUM CONNECTED WEBSITE + OWNER PORTAL

Open:
- public/index.html = public website
- admin/index.html = owner/admin portal

Prototype connection:
The public registration form and owner portal use the same browser localStorage key ("ghanaFirstMembers"), so registrations can appear in the owner dashboard when both are used on the same browser/device.

Production requirement:
This is NOT yet a secure internet-wide shared database. For a real deployment, replace localStorage with a secure backend/API and PostgreSQL/MySQL/Supabase/Firebase, add owner authentication, role-based permissions, HTTPS, audit logs, backups and privacy controls.

Suggested architecture:
Public Website -> Secure API -> Central Database <- Owner/Admin Portal
